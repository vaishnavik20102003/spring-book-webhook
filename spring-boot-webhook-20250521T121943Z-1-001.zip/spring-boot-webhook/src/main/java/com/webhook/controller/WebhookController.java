package com.webhook.controller;

import com.webhook.model.WebhookRequest;
import com.webhook.model.WebhookResponse;
import com.webhook.service.WebhookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/webhook")
public class WebhookController {

    @Autowired
    private WebhookService webhookService;

    @PostMapping("/process")
    public ResponseEntity<WebhookResponse> processWebhook(@RequestBody WebhookRequest request) {
        webhookService.processWebhookOnStartup();
        return ResponseEntity.ok().build();
    }
}