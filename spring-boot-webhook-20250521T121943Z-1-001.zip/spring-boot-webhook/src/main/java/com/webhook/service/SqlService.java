package com.webhook.service;

import org.springframework.stereotype.Service;

@Service
public class SqlService {
    
    public String getSolution(String regNo) {
        boolean isOdd = Integer.parseInt(regNo.substring(regNo.length() - 2)) % 2 != 0;
        
        if (isOdd) {
            return "SELECT p.AMOUNT as SALARY, " +
                   "CONCAT(e.FIRST_NAME, ' ', e.LAST_NAME) as NAME, " +
                   "YEAR(CURRENT_DATE) - YEAR(e.DOB) as AGE, " +
                   "d.DEPARTMENT_NAME " +
                   "FROM PAYMENTS p " +
                   "JOIN EMPLOYEE e ON p.EMP_ID = e.EMP_ID " +
                   "JOIN DEPARTMENT d ON e.DEPARTMENT = d.DEPARTMENT_ID " +
                   "WHERE DAY(p.PAYMENT_TIME) != 1 " +
                   "ORDER BY p.AMOUNT DESC " +
                   "LIMIT 1";
        } else {
            return "SELECT e.EMP_ID, " +
                   "e.FIRST_NAME, " +
                   "e.LAST_NAME, " +
                   "d.DEPARTMENT_NAME, " +
                   "(SELECT COUNT(*) FROM EMPLOYEE e2 " +
                   "WHERE e2.DEPARTMENT = e.DEPARTMENT " +
                   "AND e2.DOB > e.DOB) as YOUNGER_EMPLOYEES_COUNT " +
                   "FROM EMPLOYEE e " +
                   "JOIN DEPARTMENT d ON e.DEPARTMENT = d.DEPARTMENT_ID " +
                   "ORDER BY e.EMP_ID DESC";
        }
    }
}