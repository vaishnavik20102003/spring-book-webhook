package com.webhook.service;

import com.webhook.model.WebhookRequest;
import com.webhook.model.WebhookResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WebhookService {
    
    @Value("${webhook.generate.url}")
    private String generateWebhookUrl;
    
    @Value("${webhook.submit.url}")
    private String submitWebhookUrl;
    
    @Autowired
    private RestTemplate restTemplate;
    
    @Autowired
    private SqlService sqlService;

    public void processWebhookOnStartup() {
        WebhookRequest request = new WebhookRequest();
        request.setName("John Doe");
        request.setRegNo("REG12347");
        request.setEmail("john@example.com");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<WebhookRequest> entity = new HttpEntity<>(request, headers);

        WebhookResponse response = restTemplate.postForObject(generateWebhookUrl, entity, WebhookResponse.class);
        
        if (response != null) {
            String query = sqlService.getSolution(request.getRegNo());
            submitSolution(query, response.getAccessToken());
        }
    }

    private void submitSolution(String query, String accessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", accessToken);

        String requestBody = String.format("{\"finalQuery\": \"%s\"}", query);
        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

        restTemplate.postForObject(submitWebhookUrl, entity, String.class);
    }
}