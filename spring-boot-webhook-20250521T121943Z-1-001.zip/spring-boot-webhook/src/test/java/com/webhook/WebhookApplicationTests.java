spring-boot-webhook
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── webhook
│   │   │           ├── WebhookApplication.java
│   │   │           ├── config
│   │   │           │   └── SecurityConfig.java
│   │   │           ├── controller
│   │   │           │   └── WebhookController.java
│   │   │           ├── model
│   │   │           │   └── WebhookResponse.java
│   │   │           └── service
│   │   │               ├── SqlService.java
│   │   │               └── WebhookService.java
│   │   └── resources
│   │       └── application.properties
│   └── test
│       └── java
│           └── com
│               └── webhook
│                   └── WebhookApplicationTests.java
├── pom.xml
└── README.md