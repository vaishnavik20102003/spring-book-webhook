# Spring Boot Webhook Application

This application automatically processes a webhook flow on startup, generating and submitting SQL solutions.

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher

## Build

To build the application:

```bash
mvn clean package
```

This will create a JAR file in the `target` directory.

## Run

To run the application:

```bash
java -jar target/spring-boot-webhook-0.0.1-SNAPSHOT.jar
```

## Process Flow

1. On startup, the application sends a POST request to generate a webhook
2. Based on the registration number, it generates the appropriate SQL solution
3. The solution is submitted to the webhook URL using the provided JWT token

## Configuration

The application uses the following configuration in `application.properties`:

- Server port: 8080
- Application name: webhook-service
- Logging level: INFO